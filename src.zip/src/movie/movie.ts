export interface IMovie{

    mid:number;
    movie:string;
    actor:string;
    Genre:string;
    rating:number;
    
}