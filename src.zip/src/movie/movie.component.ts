import { Component,OnInit,OnChanges,OnDestroy } from '@angular/core';
import { IMovie } from "./movie";
import { MovieService } from "./movie.service";

@Component({
  selector: 'mov',
  templateUrl: './movie.component.html'
  //styleUrls: ['./app.component.css']
})
export class MovieComponent implements OnInit,OnChanges,OnDestroy{
//Depedency Injection of Movie service

constructor(private movieservice:MovieService){



  // console.log("At constructor");
  // this.movie="2.0";
  // console.log("movie" +this.movie)

}
ngOnInit(): void {
    this.movies=this.movieservice.getMovies();
 //console.log("at the init phase!" +this.movie);
  }

//   ngOnInit(): void {
//     this.movie="bahubali";
//  console.log("at the init phase!" +this.movie);
//   }


  ngOnChanges(): void {
   console.log("at the change detection");
  }
   ngOnDestroy(): void {
    
    console.log("at the destroy!");
  }

  movie:string="scary movie";
  imgWidth:number=80;
  imagHeight:number=50;
  movTitle="top Movies";




movies:IMovie[]=[
  
  
  
];


onRatingClicked(rate:string):void

{
  this.movTitle=rate;
}
showMovie():void{
  this.movie="scary Movie watching it is too scary"
}
}
