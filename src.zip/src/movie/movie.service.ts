import { Injectable } from '@angular/core'
import { IMovie } from "./movie";

@Injectable({
    providedIn:'root'
})


export class MovieService{
getMovies():IMovie[]{



    return[

        
            {"mid":1,"movie":"avenger", "actor":"robot","Genre":"kjk", "rating":5},
        {"mid":2,"movie":"avenger", "actor":"robot","Genre":"kjk", "rating":5},
 
      {"mid":3,"movie":"avenger", "actor":"robot","Genre":"kjk",  "rating":3},
 

        
    ];
    
}
}