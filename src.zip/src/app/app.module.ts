import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieComponent } from '../movie/movie.component';
import { AboutComponent } from '../aboutus/aboutus.component';
import { TvComponent } from '../tvshow/tv.component';
import { PipeToPower } from '../shared/transform-spaces.pipe';
import { HomeComponent } from '../Home/home.component';
import { MovieDetailComponent } from '../movie-detail/movie-detail.component';
import { MovieRating } from '../shared/rating.component';

@NgModule({
  declarations: [
    AppComponent,MovieComponent,AboutComponent,TvComponent,HomeComponent,PipeToPower,MovieDetailComponent,MovieRating
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
