import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MovieComponent } from './../movie/movie.component';
import { HomeComponent } from './../Home/home.component';
import { MovieDetailComponent } from'./../movie-detail/movie-detail.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'movies',component:MovieComponent},
//{path:'',component:HomeComponent,pathMatch:'full'},
  {path:'home',component:HomeComponent},
{path:'movies/:id',component:MovieDetailComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
