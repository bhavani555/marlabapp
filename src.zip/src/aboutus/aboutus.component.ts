import { Component } from '@angular/core';

@Component({
  selector: 'about',
  template: `<h1>About Us</h1>`,
  //styleUrls: ['./app.component.css']
})
export class AboutComponent{
  title = 'marlabapps';
}
