import { Pipe,PipeTransform } from '@angular/core';



@Pipe({
    name:'PipeToPower'
})

export class PipeToPower implements PipeTransform{
    transform(value: number,power:number): number{
        return value*power;
    }

}