import { Component, Input,EventEmitter,Output   } from '@angular/core';



@Component({
  selector: 'mov-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class MovieRating {
@Input() rating:number;
starWidth:number;
@Output() ratingClick:EventEmitter<String> =new EventEmitter<String>();

ngOnChanges():void{
    this.starWidth=this.rating * 75/5;
}
onclick():void{
    this.ratingClick.emit('the movie rating ${this.rating} is clicked');
}
}
