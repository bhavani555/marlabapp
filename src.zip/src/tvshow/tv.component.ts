import { Component } from '@angular/core';

@Component({
  selector: 'tv',
  template: `<h1>welcome to tv {{showName}} show </h1>`,
  //styleUrls: ['./app.component.css']
}) 
export class TvComponent{
 showName:string='GoT';
 broadcaster:string='Netflix';
 
}
