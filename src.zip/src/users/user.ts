export class User{



constructor(
  
    public firstName='',
     public lastName='',
    
     public email='',
    
     public state:'',
    
    
    
)


}