import { }
import { User } from "./user";

@Component

export class UserComponent implements onInit()
{
user=new User();





constructor(){


}
}